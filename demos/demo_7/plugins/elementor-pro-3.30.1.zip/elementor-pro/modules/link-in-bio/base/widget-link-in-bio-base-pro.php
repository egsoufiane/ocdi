<?php

namespace ElementorPro\Modules\LinkInBio\Base;

use Elementor\Modules\LinkInBio\Base\Widget_Link_In_Bio_Base;

abstract class Widget_Link_In_Bio_Base_Pro extends Widget_Link_In_Bio_Base {
}
